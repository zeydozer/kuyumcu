<div class="row mt-3 align-items-center" id="pagination" style="display: none">
  <div class="col">
    <a href="#" id="prev-page" class="mr-2">
      <i class="bi-chevron-double-left"></i>
    </a>
    <select name="page" class="form-control w-auto d-inline-block" id="select-page"></select>
    <a href="#" id="next-page" class="ml-2">
      <i class="bi-chevron-double-right"></i>
    </a>
  </div>
  <div class="col text-end">
    <b>Toplam:</b>
    <total></total>
  </div>
</div>